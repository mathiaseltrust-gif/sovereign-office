import { Router, type IRouter } from "express";
import { logger } from "../../lib/logger.js";
import uploadRouter from "./routes/upload.js";
import analyzeRouter from "./routes/analyze.js";
import { seedIntakeAiTables } from "./db/seed.js";

/**
 * intake_ai plugin — mounts all intake routes and seeds lookup tables.
 *
 * Full public paths (registered under /api/intake in routes/index.ts):
 *   POST /api/intake/upload   — OCR + session creation
 *   POST /api/intake/analyze  — full AI analysis pipeline
 */
const intakeRouter: IRouter = Router();

intakeRouter.use(uploadRouter);
intakeRouter.use(analyzeRouter);

// Seed lookup tables asynchronously on startup.
// Inserts only if the tables are empty — fully idempotent.
void (async () => {
  try {
    await seedIntakeAiTables();
    logger.info("intake_ai: lookup tables seeded");
  } catch (err) {
    logger.error({ err }, "intake_ai: seeding failed — manual seed may be required");
  }
})();

export default intakeRouter;
