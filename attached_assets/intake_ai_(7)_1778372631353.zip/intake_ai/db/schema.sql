-- ============================================================
-- intake_ai plugin — database schema
-- Run once against the target PostgreSQL database.
-- All tables use IF NOT EXISTS so this script is idempotent.
-- ============================================================

-- Tracks an intake processing session (one session per intake event)
CREATE TABLE IF NOT EXISTS intake_sessions (
    session_id      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now(),
    status          TEXT        DEFAULT 'pending',   -- pending | processing | complete | error
    form_type       TEXT,                            -- recommended form type from AI
    jurisdiction    TEXT,                            -- e.g. tribal, federal, state
    state           TEXT,                            -- US state abbreviation
    parties         JSONB,                           -- { names: string[], agencies: string[] }
    issues          JSONB,                           -- string[]
    timeline        JSONB,                           -- { date: string, event: string }[]
    summary         TEXT,
    applied_rules   JSONB,                           -- AppliedRule[]
    populated_form  JSONB                            -- PopulatedForm | null
);

-- Stores uploaded documents and their OCR-extracted text
CREATE TABLE IF NOT EXISTS intake_documents (
    doc_id      UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id  UUID        NOT NULL REFERENCES intake_sessions(session_id),
    created_at  TIMESTAMPTZ DEFAULT now(),
    filename    TEXT        NOT NULL,
    mimetype    TEXT,
    file_size   INTEGER,
    ocr_text    TEXT,
    page_count  INTEGER,
    doc_hash    TEXT        UNIQUE       -- SHA-256 of raw bytes, prevents duplicate uploads
);

-- Legal corpus — provisions, statutes, regulations searched during analysis
CREATE TABLE IF NOT EXISTS legal_provisions (
    provision_id  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at    TIMESTAMPTZ DEFAULT now(),
    title         TEXT        NOT NULL,
    citation      TEXT,                  -- e.g. 25 U.S.C. § 177
    body          TEXT        NOT NULL,  -- full provision text
    jurisdiction  TEXT,                  -- tribal | federal | state
    state         TEXT,                  -- US state abbreviation
    tags          JSONB                  -- string[] of topic tags
);

-- State + jurisdiction rules applied by the rules engine
CREATE TABLE IF NOT EXISTS core_state_rules (
    rule_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at     TIMESTAMPTZ DEFAULT now(),
    state          TEXT        NOT NULL,  -- US state abbreviation
    jurisdiction   TEXT        NOT NULL,  -- tribal | federal | state | concurrent
    rule_type      TEXT        NOT NULL,  -- filing_deadline | required_form | notice_requirement | etc.
    rule_body      TEXT        NOT NULL,  -- human-readable rule description
    priority       INTEGER     DEFAULT 0, -- higher = applied first
    effective_date DATE,
    expires_date   DATE
);

-- Form templates; template_fields is a JSON array of { key, label, type }
CREATE TABLE IF NOT EXISTS forms_registry (
    form_id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at       TIMESTAMPTZ DEFAULT now(),
    form_code        TEXT        UNIQUE NOT NULL,  -- e.g. TC-001
    form_name        TEXT        NOT NULL,
    form_type        TEXT        NOT NULL,         -- complaint | motion | petition | notice | other
    jurisdiction     TEXT,
    state            TEXT,
    template_fields  JSONB                         -- { key: string, label: string, type: string }[]
);
