import { db, legalProvisions, coreStateRules, formsRegistry } from "@workspace/db";
import { sql } from "drizzle-orm";

// ─── Legal Provisions ────────────────────────────────────────────────────────

const LEGAL_PROVISIONS = [
  {
    title: "Worcester v. Georgia — Tribal Sovereignty",
    citation: "31 U.S. 515 (1832)",
    body: "Indian nations are distinct, independent political communities, retaining their original natural rights, with the exception of such as have been expressly surrendered. The Cherokee nation is a distinct community, occupying its own territory, with boundaries accurately described, in which the laws of Georgia can have no force.",
    jurisdiction: "federal",
    state: null,
    tags: ["sovereignty", "tribal jurisdiction", "state preemption", "Cherokee"],
  },
  {
    title: "Non-Intercourse Act — Trade and Intercourse",
    citation: "25 U.S.C. § 177",
    body: "No purchase, grant, lease, or other conveyance of lands, or of any title or claim thereto, from any Indian nation or tribe of Indians, shall be of any validity in law or equity, unless the same be made by treaty or convention entered into pursuant to the Constitution. Liens, assessments, and encumbrances placed on Indian trust land by non-tribal parties without federal approval are void under this provision.",
    jurisdiction: "federal",
    state: null,
    tags: ["non-intercourse act", "land transfer", "lien", "assessment", "trust land"],
  },
  {
    title: "Indian Country Defined",
    citation: "18 U.S.C. § 1151",
    body: "Except as otherwise provided in sections 1154 and 1156 of this title, the term 'Indian country' means: (a) all land within the limits of any Indian reservation under the jurisdiction of the United States Government; (b) all dependent Indian communities within the borders of the United States whether within the original or subsequently acquired territory thereof; and (c) all Indian allotments, the Indian titles to which have not been extinguished.",
    jurisdiction: "federal",
    state: null,
    tags: ["indian country", "reservation", "allotment", "dependent community", "jurisdiction"],
  },
  {
    title: "McClanahan v. Arizona State Tax Commission — State Tax Preemption",
    citation: "411 U.S. 164 (1973)",
    body: "The State of Arizona has no jurisdiction to impose its income tax on income earned by a Navajo Indian residing on the Navajo Reservation. The trend has been away from the idea of inherent Indian sovereignty as a bar to state jurisdiction, and toward reliance on federal preemption. State taxation of reservation Indians is preempted by federal law.",
    jurisdiction: "federal",
    state: "AZ",
    tags: ["state tax", "preemption", "reservation", "income tax", "Arizona"],
  },
  {
    title: "Acquisition of Land in Trust",
    citation: "25 U.S.C. § 465",
    body: "The Secretary of the Interior is authorized, in his discretion, to acquire, through purchase, relinquishment, gift, exchange, or assignment, any interest in lands, water rights, or surface rights to lands, within or without existing reservations, including trust or restricted allotments, for the purpose of providing land for Indians. Title to any lands or rights acquired pursuant to this Act shall be taken in the name of the United States in trust for the Indian tribe or individual Indian for whom the land is acquired.",
    jurisdiction: "federal",
    state: null,
    tags: ["trust acquisition", "land", "indian tribes", "secretary of interior"],
  },
  {
    title: "Federal Recognition — Definitions",
    citation: "25 CFR § 83.1",
    body: "A 'federally recognized Indian tribe' means an Indian or Alaska Native tribe, band, nation, pueblo, village, or community that the Secretary of the Interior acknowledges to exist as an Indian tribe. Federally recognized tribes possess inherent sovereign powers, including the power to establish their own form of government, determine membership, regulate domestic relations, make and enforce laws, tax, license and regulate activities within their territory.",
    jurisdiction: "federal",
    state: null,
    tags: ["federal recognition", "sovereign powers", "tribal government", "membership"],
  },
  {
    title: "Tribal Land Restrictions — Prohibited Alienation",
    citation: "25 CFR § 152.22",
    body: "No conveyance of trust or restricted Indian land shall be made or approved which would constitute an unreasonable restraint on alienation. Encumbrances, liens, assessments, or other charges placed on trust or restricted land without the approval of the Bureau of Indian Affairs are void and of no legal effect. The BIA must approve any disposition of interests in trust or restricted land.",
    jurisdiction: "federal",
    state: null,
    tags: ["trust land", "alienation", "encumbrance", "BIA approval", "restriction"],
  },
  {
    title: "Indian Civil Rights Act — Due Process",
    citation: "25 U.S.C. § 1302",
    body: "No Indian tribe in exercising powers of self-government shall deny to any person within its jurisdiction the equal protection of its laws or deprive any person of liberty or property without due process of law. Tribal courts must provide procedural due process in all proceedings affecting individual rights.",
    jurisdiction: "tribal",
    state: null,
    tags: ["ICRA", "due process", "equal protection", "tribal courts", "self-government"],
  },
];

// ─── Core State Rules ─────────────────────────────────────────────────────────

const CORE_STATE_RULES = [
  // Arizona
  {
    state: "AZ",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "Issue Notice of Federal Review (NFR) — Non-Intercourse Act violation on Arizona trust land",
    priority: 10,
  },
  {
    state: "AZ",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-NFR-001 (Notice of Federal Review); TC-RESP-001 (Sovereignty Response)",
    priority: 9,
  },
  {
    state: "AZ",
    jurisdiction: "tribal",
    rule_type: "jurisdiction_note",
    rule_body: "Arizona tribes with federal recognition retain exclusive jurisdiction over trust land. State tax and lien authority is preempted under McClanahan v. Arizona (411 U.S. 164).",
    priority: 8,
  },
  // New Mexico
  {
    state: "NM",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "File Sovereignty Response — New Mexico state actions on Pueblo or Navajo trust land require formal assertion of Tribal jurisdiction",
    priority: 10,
  },
  {
    state: "NM",
    jurisdiction: "federal",
    rule_type: "recommended_action",
    rule_body: "Notify Bureau of Indian Affairs and Issue NFR — federal nexus required for New Mexico trust land matters",
    priority: 10,
  },
  {
    state: "NM",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-RESP-001 (Sovereignty Response); TC-NFR-001 (Notice of Federal Review)",
    priority: 9,
  },
  // Oklahoma
  {
    state: "OK",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "File Tribal Court Complaint — Oklahoma tribal jurisdiction restored under McGirt v. Oklahoma (2020). Private actor encroachments on trust or restricted allotments are cognizable in Tribal Court.",
    priority: 10,
  },
  {
    state: "OK",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-COMP-001 (Tribal Court Complaint); TC-PET-001 (Petition for Tribal Jurisdiction)",
    priority: 9,
  },
  // Montana
  {
    state: "MT",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "File Sovereignty Response — Montana v. United States (1981) limits Tribal civil jurisdiction over non-members on fee land. Verify land status before asserting full jurisdiction.",
    priority: 10,
  },
  {
    state: "MT",
    jurisdiction: "tribal",
    rule_type: "jurisdiction_note",
    rule_body: "Montana tribes may regulate non-member conduct on trust land without restriction. On fee land, jurisdiction requires consensual relationship or direct threat to tribal governance.",
    priority: 8,
  },
  // South Dakota
  {
    state: "SD",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "Issue NFR and Request Federal Intervention — South Dakota treaty violations on Sioux Nation lands invoke 1868 Fort Laramie Treaty protections",
    priority: 10,
  },
  {
    state: "SD",
    jurisdiction: "federal",
    rule_type: "recommended_action",
    rule_body: "Request Federal Intervention — Sioux Nation treaty rights under 1868 Fort Laramie Treaty are federally protected. Engage U.S. Attorney and BIA.",
    priority: 10,
  },
  // Washington
  {
    state: "WA",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "Issue Notice of Federal Review (NFR) — Washington state tax or lien on reservation land is preempted by federal Indian law",
    priority: 10,
  },
  {
    state: "WA",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-NFR-001 (Notice of Federal Review); TC-MOT-001 (Motion for Federal Intervention)",
    priority: 9,
  },
  // Minnesota
  {
    state: "MN",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "File Tribal Court Complaint — Minnesota tribal courts have exclusive jurisdiction over all civil matters arising on trust or reservation land",
    priority: 10,
  },
  {
    state: "MN",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-COMP-001 (Tribal Court Complaint); TC-RESP-001 (Sovereignty Response)",
    priority: 9,
  },
  // California
  {
    state: "CA",
    jurisdiction: "state",
    rule_type: "recommended_action",
    rule_body: "File Sovereignty Response — California concurrent jurisdiction under Public Law 280 does not extinguish tribal civil jurisdiction. Assert tribal authority over internal matters.",
    priority: 10,
  },
  {
    state: "CA",
    jurisdiction: "tribal",
    rule_type: "required_form",
    rule_body: "TC-RESP-001 (Sovereignty Response); TC-PET-001 (Petition for Tribal Jurisdiction Determination)",
    priority: 9,
  },
  // Generic federal jurisdiction
  {
    state: "US",
    jurisdiction: "federal",
    rule_type: "recommended_action",
    rule_body: "Issue Notice of Federal Review (NFR) and Notify BIA — Federal trust responsibility invoked. Document all intrusions for potential DOJ referral.",
    priority: 10,
  },
  {
    state: "US",
    jurisdiction: "federal",
    rule_type: "required_form",
    rule_body: "TC-NFR-001 (Notice of Federal Review); TC-MOT-001 (Motion for Federal Intervention)",
    priority: 9,
  },
  // Generic tribal jurisdiction (fallback)
  {
    state: "US",
    jurisdiction: "tribal",
    rule_type: "recommended_action",
    rule_body: "Issue Notice of Federal Review (NFR) — Tribal sovereignty assertion required for any non-member action affecting trust land",
    priority: 5,
  },
];

// ─── Forms Registry ───────────────────────────────────────────────────────────

const FORMS_REGISTRY = [
  {
    form_code: "TC-NFR-001",
    form_name: "Notice of Federal Review",
    form_type: "notice",
    jurisdiction: "federal",
    state: null,
    template_fields: [
      { key: "petitioner_name", label: "Petitioner / Tribe Name", type: "text" },
      { key: "respondent_agency", label: "Respondent Agency or Party", type: "text" },
      { key: "action_type", label: "Type of Action", type: "text" },
      { key: "land_status", label: "Land Status (trust / allotment / fee)", type: "text" },
      { key: "issues", label: "Issues Raised", type: "textarea" },
      { key: "jurisdiction", label: "Jurisdictional Basis", type: "text" },
      { key: "state", label: "State", type: "text" },
      { key: "summary", label: "Summary of Matter", type: "textarea" },
    ],
  },
  {
    form_code: "TC-COMP-001",
    form_name: "Tribal Court Complaint",
    form_type: "complaint",
    jurisdiction: "tribal",
    state: null,
    template_fields: [
      { key: "petitioner_name", label: "Complainant Name", type: "text" },
      { key: "petitioner_names", label: "All Parties", type: "list" },
      { key: "respondent_agency", label: "Respondent", type: "text" },
      { key: "issues", label: "Claims / Causes of Action", type: "list" },
      { key: "timeline", label: "Chronology of Events", type: "timeline" },
      { key: "summary", label: "Statement of Facts", type: "textarea" },
      { key: "jurisdiction", label: "Jurisdictional Statement", type: "text" },
    ],
  },
  {
    form_code: "TC-RESP-001",
    form_name: "Sovereignty Response",
    form_type: "respond",
    jurisdiction: "tribal",
    state: null,
    template_fields: [
      { key: "petitioner_name", label: "Responding Tribe / Entity", type: "text" },
      { key: "respondent_agency", label: "Acting Party", type: "text" },
      { key: "respondent_agencies", label: "All Acting Parties", type: "list" },
      { key: "issues", label: "Jurisdictional Violations", type: "list" },
      { key: "summary", label: "Sovereignty Assertion", type: "textarea" },
      { key: "jurisdiction", label: "Applicable Jurisdiction", type: "text" },
      { key: "state", label: "State", type: "text" },
    ],
  },
  {
    form_code: "TC-MOT-001",
    form_name: "Motion for Federal Intervention",
    form_type: "motion",
    jurisdiction: "federal",
    state: null,
    template_fields: [
      { key: "petitioner_name", label: "Moving Party", type: "text" },
      { key: "respondent_agency", label: "Adverse Party / Agency", type: "text" },
      { key: "issues", label: "Grounds for Intervention", type: "list" },
      { key: "timeline", label: "Timeline of Events", type: "timeline" },
      { key: "summary", label: "Statement of Relief Requested", type: "textarea" },
      { key: "jurisdiction", label: "Federal Jurisdictional Basis", type: "text" },
    ],
  },
  {
    form_code: "TC-PET-001",
    form_name: "Petition for Tribal Jurisdiction Determination",
    form_type: "petition",
    jurisdiction: "tribal",
    state: null,
    template_fields: [
      { key: "petitioner_name", label: "Petitioner", type: "text" },
      { key: "respondent_agencies", label: "Adverse Parties", type: "list" },
      { key: "issues", label: "Jurisdictional Questions Presented", type: "list" },
      { key: "summary", label: "Basis for Tribal Jurisdiction", type: "textarea" },
      { key: "jurisdiction", label: "Jurisdiction Claimed", type: "text" },
      { key: "state", label: "State", type: "text" },
    ],
  },
];

// ─── Seed runner ──────────────────────────────────────────────────────────────

export async function seedIntakeAiTables(): Promise<void> {
  // legal_provisions
  const [{ lpCount }] = await db
    .select({ lpCount: sql<string>`count(*)` })
    .from(legalProvisions);
  if (Number(lpCount) === 0) {
    await db.insert(legalProvisions).values(LEGAL_PROVISIONS);
  }

  // core_state_rules
  const [{ csrCount }] = await db
    .select({ csrCount: sql<string>`count(*)` })
    .from(coreStateRules);
  if (Number(csrCount) === 0) {
    await db.insert(coreStateRules).values(CORE_STATE_RULES);
  }

  // forms_registry
  const [{ frCount }] = await db
    .select({ frCount: sql<string>`count(*)` })
    .from(formsRegistry);
  if (Number(frCount) === 0) {
    await db.insert(formsRegistry).values(FORMS_REGISTRY);
  }
}
