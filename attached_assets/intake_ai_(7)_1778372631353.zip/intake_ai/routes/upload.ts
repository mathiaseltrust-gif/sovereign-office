import { Router, type IRouter } from "express";
import multer from "multer";
import { createHash } from "crypto";
import { eq } from "drizzle-orm";
import { db, intakeSessions, intakeDocuments } from "@workspace/db";
import { extractTextFromPdf } from "../services/ocr.js";

const router: IRouter = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 },
});

/**
 * POST /api/intake/upload
 *
 * Accepts a PDF via multipart field "file".
 * 1. Runs OCR (pdf-parse) to extract plain text.
 * 2. Creates an intake_session record.
 * 3. Stores the document in intake_documents with the OCR text.
 * 4. Returns session_id, doc_id, and a link to the next step.
 *
 * Returns 409 if the same file (same SHA-256) was already uploaded.
 */
router.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.file) {
    res.status(400).json({
      error: "No file uploaded. Use multipart field name 'file'.",
    });
    return;
  }

  const isAcceptedType =
    req.file.mimetype === "application/pdf" ||
    req.file.originalname.toLowerCase().endsWith(".pdf");

  if (!isAcceptedType) {
    res.status(415).json({ error: "Only PDF files are supported." });
    return;
  }

  const docHash = createHash("sha256").update(req.file.buffer).digest("hex");

  const existing = await db
    .select({
      doc_id: intakeDocuments.doc_id,
      session_id: intakeDocuments.session_id,
    })
    .from(intakeDocuments)
    .where(eq(intakeDocuments.doc_hash, docHash))
    .limit(1);

  if (existing.length > 0) {
    res.status(409).json({
      error: "Duplicate document. This file has already been processed.",
      doc_id: existing[0]!.doc_id,
      session_id: existing[0]!.session_id,
    });
    return;
  }

  let ocr: { text: string; pageCount: number; charCount: number };
  try {
    ocr = await extractTextFromPdf(req.file.buffer);
  } catch (err) {
    req.log.error({ err }, "OCR extraction failed");
    res
      .status(422)
      .json({ error: "Failed to parse PDF. Ensure the file is a valid PDF." });
    return;
  }

  const [session] = await db
    .insert(intakeSessions)
    .values({ status: "pending" })
    .returning();

  const [doc] = await db
    .insert(intakeDocuments)
    .values({
      session_id: session!.session_id,
      filename: req.file.originalname,
      mimetype: req.file.mimetype,
      file_size: req.file.size,
      ocr_text: ocr.text,
      page_count: ocr.pageCount,
      doc_hash: docHash,
    })
    .returning();

  res.status(201).json({
    session_id: session!.session_id,
    doc_id: doc!.doc_id,
    filename: req.file.originalname,
    page_count: ocr.pageCount,
    char_count: ocr.charCount,
    status: "pending",
    next_step: "/api/intake/analyze",
  });
});

export default router;
