import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, inArray } from "drizzle-orm";
import { db, intakeSessions, intakeDocuments, formsRegistry } from "@workspace/db";
import { extractIntakeData } from "../services/extraction.js";
import { searchLegalProvisions } from "../services/legalSearch.js";
import { applyStateRules } from "../services/rulesEngine.js";
import { populateForm } from "../services/formPopulation.js";
import { deriveActions } from "../services/actionEngine.js";

const router: IRouter = Router();

const analyzeBodySchema = z.object({
  session_id: z.string().uuid("session_id must be a valid UUID"),
  // Optional overrides / enrichment
  state: z.string().max(10).optional(),
  jurisdiction: z.string().max(100).optional(),
  narrative_text: z.string().max(20000).optional(),
  document_ids: z.array(z.string().uuid()).optional(),
});

/**
 * POST /api/intake/analyze
 *
 * Full analysis pipeline:
 * 1. Load session + documents (optionally filtered by document_ids).
 * 2. Combine OCR text with any narrative_text provided.
 * 3. AI extraction — parties, issues, timeline, summary, jurisdiction, state, form_type.
 * 4. In parallel: legal corpus search · rules engine · form population.
 * 5. Action engine — recommended_action, reasoning, next-step options.
 * 6. Forms list — all available forms for the extracted form_type.
 * 7. Persist full analysis to intake_sessions.
 * 8. Return comprehensive structured response.
 */
router.post("/analyze", async (req, res) => {
  const parsed = analyzeBodySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Invalid request body",
      details: parsed.error.issues,
    });
    return;
  }

  const { session_id, state, jurisdiction, narrative_text, document_ids } =
    parsed.data;

  // ── Load session ────────────────────────────────────────────────────────────
  const sessions = await db
    .select()
    .from(intakeSessions)
    .where(eq(intakeSessions.session_id, session_id))
    .limit(1);

  if (sessions.length === 0) {
    res.status(404).json({ error: "Session not found." });
    return;
  }

  // ── Load documents ──────────────────────────────────────────────────────────
  const docsQuery = db
    .select()
    .from(intakeDocuments)
    .where(
      document_ids && document_ids.length > 0
        ? inArray(intakeDocuments.doc_id, document_ids)
        : eq(intakeDocuments.session_id, session_id),
    );

  const docs = await docsQuery;

  if (docs.length === 0) {
    res.status(422).json({
      error:
        "No documents found for this session. Upload a document first via POST /api/intake/upload.",
    });
    return;
  }

  await db
    .update(intakeSessions)
    .set({ status: "processing", updated_at: new Date() })
    .where(eq(intakeSessions.session_id, session_id));

  // ── Build full text ─────────────────────────────────────────────────────────
  const ocrText = docs.map((d) => d.ocr_text ?? "").join("\n\n---\n\n");
  const fullText = narrative_text
    ? `${ocrText}\n\n--- Narrative / Additional Context ---\n${narrative_text}`
    : ocrText;

  // ── AI extraction ────────────────────────────────────────────────────────────
  let extraction;
  try {
    extraction = await extractIntakeData(fullText);
  } catch (err) {
    req.log.error({ err }, "AI extraction failed");
    await db
      .update(intakeSessions)
      .set({ status: "error", updated_at: new Date() })
      .where(eq(intakeSessions.session_id, session_id));
    res.status(502).json({ error: "AI extraction failed. Please try again." });
    return;
  }

  // Apply overrides from request body (caller may know the state/jurisdiction
  // from external context that the document alone does not reveal)
  const effectiveState = state?.toUpperCase() || extraction.state;
  const effectiveJurisdiction = jurisdiction?.toLowerCase() || extraction.jurisdiction;
  extraction.state = effectiveState;
  extraction.jurisdiction = effectiveJurisdiction;

  // ── Parallel services ────────────────────────────────────────────────────────
  const searchTerms = [
    ...extraction.issues,
    ...extraction.parties.agencies,
  ]
    .filter(Boolean)
    .slice(0, 12);

  const [legalMatches, appliedRules, populatedForm] = await Promise.all([
    searchLegalProvisions(searchTerms, effectiveJurisdiction, effectiveState),
    applyStateRules(effectiveState, effectiveJurisdiction),
    populateForm(extraction),
  ]);

  // ── Action engine ────────────────────────────────────────────────────────────
  const { recommended_action, reasoning, options } = deriveActions(
    extraction,
    appliedRules,
    legalMatches,
  );

  // ── Available forms ──────────────────────────────────────────────────────────
  // Return all forms from the registry so the UI can present relevant choices.
  const allForms = await db.select().from(formsRegistry);
  const forms = allForms.map((f) => ({
    form_code: f.form_code,
    form_name: f.form_name,
    form_type: f.form_type,
    jurisdiction: f.jurisdiction,
    recommended: f.form_type === extraction.form_type,
  }));

  // ── formData — pre-filled fields ─────────────────────────────────────────────
  const formData = {
    petitioner_name: extraction.parties.names[0] ?? "",
    petitioner_names: extraction.parties.names,
    respondent_agency: extraction.parties.agencies[0] ?? "",
    respondent_agencies: extraction.parties.agencies,
    issues: extraction.issues,
    timeline: extraction.timeline,
    summary: extraction.summary,
    jurisdiction: effectiveJurisdiction,
    state: effectiveState,
    form_type: extraction.form_type,
    recommended_action,
    ...(populatedForm?.fields ?? {}),
  };

  // ── Group rules by type ───────────────────────────────────────────────────────
  const rulesGrouped: Record<string, string[]> = {};
  for (const rule of appliedRules) {
    if (!rulesGrouped[rule.rule_type]) rulesGrouped[rule.rule_type] = [];
    rulesGrouped[rule.rule_type]!.push(rule.rule_body);
  }

  // ── Persist full analysis ─────────────────────────────────────────────────────
  const [updated] = await db
    .update(intakeSessions)
    .set({
      status: "complete",
      updated_at: new Date(),
      form_type: extraction.form_type,
      jurisdiction: effectiveJurisdiction,
      state: effectiveState,
      parties: extraction.parties,
      issues: extraction.issues,
      timeline: extraction.timeline,
      summary: extraction.summary,
      applied_rules: appliedRules,
      populated_form: populatedForm,
    })
    .where(eq(intakeSessions.session_id, session_id))
    .returning();

  // ── Response ──────────────────────────────────────────────────────────────────
  res.status(200).json({
    success: true,
    session: {
      session_id: updated!.session_id,
      status: updated!.status,
      created_at: updated!.created_at,
      updated_at: updated!.updated_at,
    },
    extracted: extraction,
    legalMatches: legalMatches,
    rules: {
      applied: appliedRules,
      grouped: rulesGrouped,
      state: effectiveState,
      jurisdiction: effectiveJurisdiction,
    },
    recommended_action,
    reasoning,
    options,
    forms,
    formData,
  });
});

export default router;
