import { db } from "@workspace/db";
import { coreStateRules } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";

export interface AppliedRule {
  rule_id: string;
  rule_type: string;
  rule_body: string;
  priority: number;
}

/**
 * Apply state + jurisdiction rules from core_state_rules.
 *
 * Queries all rules that match the given state AND jurisdiction,
 * ordered by priority (highest first). If only one of the two is
 * provided, that single condition is used.
 */
export async function applyStateRules(
  state: string,
  jurisdiction: string,
): Promise<AppliedRule[]> {
  if (!state && !jurisdiction) return [];

  const hasState = state.trim().length > 0;
  const hasJurisdiction = jurisdiction.trim().length > 0;

  const condition =
    hasState && hasJurisdiction
      ? and(
          eq(coreStateRules.state, state.toUpperCase()),
          eq(coreStateRules.jurisdiction, jurisdiction.toLowerCase()),
        )
      : hasState
        ? eq(coreStateRules.state, state.toUpperCase())
        : eq(coreStateRules.jurisdiction, jurisdiction.toLowerCase());

  const rows = await db
    .select()
    .from(coreStateRules)
    .where(condition)
    .orderBy(desc(coreStateRules.priority));

  return rows.map((row) => ({
    rule_id: row.rule_id,
    rule_type: row.rule_type,
    rule_body: row.rule_body,
    priority: row.priority ?? 0,
  }));
}
