import pdfParse from "pdf-parse/lib/pdf-parse.js";

export interface OcrResult {
  text: string;
  pageCount: number;
  charCount: number;
}

/**
 * Extract plain text from a PDF buffer using pdf-parse.
 * Mirrors the same extraction approach used in /api/classify.
 */
export async function extractTextFromPdf(buffer: Buffer): Promise<OcrResult> {
  const parsed = await pdfParse(buffer);
  return {
    text: parsed.text,
    pageCount: parsed.numpages,
    charCount: parsed.text.length,
  };
}
