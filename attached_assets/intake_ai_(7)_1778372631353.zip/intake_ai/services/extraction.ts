import { openai } from "@workspace/integrations-openai-ai-server";

export interface ExtractedIntake {
  parties: {
    names: string[];
    agencies: string[];
  };
  issues: string[];
  timeline: { date: string; event: string }[];
  summary: string;
  jurisdiction: string;
  state: string;
  form_type: string;
}

const SYSTEM_PROMPT = `You are a tribal court intake analyst. Extract structured intake data from the provided document text.
Return ONLY a valid JSON object with these exact keys:

- parties: { names: string[], agencies: string[] }
    Individual people named in the document (names) and government or organizational bodies (agencies).
- issues: string[]
    Legal issues, claims, violations, or disputes raised. One concise phrase per issue.
- timeline: { date: string, event: string }[]
    Chronological events. Use ISO 8601 dates (YYYY-MM-DD) where possible; use "" if unknown.
- summary: string
    2–3 sentence plain-language summary of the matter.
- jurisdiction: string
    Controlling jurisdictional authority — e.g. "tribal", "federal", "state", or "concurrent".
- state: string
    US state two-letter abbreviation (e.g. "AZ") or "" if not determinable.
- form_type: string
    Recommended intake form type — one of: "complaint", "motion", "petition", "notice", "other".

Do NOT include any explanation, markdown, or commentary — respond with raw JSON only.`;

export async function extractIntakeData(ocrText: string): Promise<ExtractedIntake> {
  const completion = await openai.chat.completions.create({
    model: "gpt-4o",
    max_tokens: 1024,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: `Document text:\n\n${ocrText.slice(0, 14000)}`,
      },
    ],
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content ?? "{}";
  const parsed = JSON.parse(raw) as Partial<ExtractedIntake>;

  return {
    parties: parsed.parties ?? { names: [], agencies: [] },
    issues: Array.isArray(parsed.issues) ? parsed.issues : [],
    timeline: Array.isArray(parsed.timeline) ? parsed.timeline : [],
    summary: parsed.summary ?? "",
    jurisdiction: parsed.jurisdiction ?? "",
    state: parsed.state ?? "",
    form_type: parsed.form_type ?? "other",
  };
}
