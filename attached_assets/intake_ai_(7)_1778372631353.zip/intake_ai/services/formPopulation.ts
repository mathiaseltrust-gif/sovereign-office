import { db } from "@workspace/db";
import { formsRegistry } from "@workspace/db";
import { eq } from "drizzle-orm";
import type { ExtractedIntake } from "./extraction.js";

export interface PopulatedForm {
  form_code: string;
  form_name: string;
  form_type: string;
  fields: Record<string, unknown>;
}

type TemplateField = {
  key: string;
  label: string;
  type: string;
};

/**
 * Look up the recommended form template in forms_registry and populate
 * its fields with data extracted by the AI extraction service.
 *
 * If no template is found for the extraction's form_type, returns null.
 * If the template has no template_fields defined, all extracted values
 * are placed directly in the fields map.
 */
export async function populateForm(
  extraction: ExtractedIntake,
): Promise<PopulatedForm | null> {
  const rows = await db
    .select()
    .from(formsRegistry)
    .where(eq(formsRegistry.form_type, extraction.form_type))
    .limit(1);

  const template = rows[0];
  if (!template) return null;

  const templateFields =
    (template.template_fields as TemplateField[] | null) ?? [];

  const valueMap: Record<string, unknown> = {
    petitioner_name: extraction.parties.names[0] ?? "",
    petitioner_names: extraction.parties.names,
    respondent_agency: extraction.parties.agencies[0] ?? "",
    respondent_agencies: extraction.parties.agencies,
    issues: extraction.issues,
    timeline: extraction.timeline,
    summary: extraction.summary,
    jurisdiction: extraction.jurisdiction,
    state: extraction.state,
    form_type: extraction.form_type,
  };

  const populated: Record<string, unknown> = {};

  if (templateFields.length > 0) {
    for (const field of templateFields) {
      populated[field.key] = valueMap[field.key] ?? "";
    }
  } else {
    Object.assign(populated, valueMap);
  }

  return {
    form_code: template.form_code,
    form_name: template.form_name,
    form_type: template.form_type,
    fields: populated,
  };
}
