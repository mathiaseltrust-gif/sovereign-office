import type { ExtractedIntake } from "./extraction.js";
import type { AppliedRule } from "./rulesEngine.js";
import type { LegalSearchResult } from "./legalSearch.js";

export interface NextStepOption {
  label: string;
  action: string;
  endpoint?: string;
  description: string;
  priority: number;
}

export interface ActionResult {
  recommended_action: string;
  reasoning: string;
  options: NextStepOption[];
}

const ALL_OPTIONS: NextStepOption[] = [
  {
    label: "Issue Notice of Federal Review",
    action: "nfr",
    endpoint: "/api/generate-nfr",
    description:
      "Assert federal jurisdiction under the Non-Intercourse Act (25 U.S.C. § 177) and Worcester v. Georgia. Formally notifies the acting party and relevant federal agencies.",
    priority: 1,
  },
  {
    label: "File Tribal Court Complaint",
    action: "complaint",
    endpoint: "/court-docs/create",
    description:
      "Initiate formal proceedings in Tribal Court. Asserts exclusive Tribal jurisdiction over matters occurring on trust or allotted land.",
    priority: 2,
  },
  {
    label: "File Sovereignty Response",
    action: "respond",
    endpoint: "/court-docs/create",
    description:
      "Issue a formal sovereign response documenting the jurisdictional violation and asserting Tribal authority under federal Indian law.",
    priority: 3,
  },
  {
    label: "Notify Bureau of Indian Affairs",
    action: "bia",
    description:
      "Notify the BIA of the jurisdictional intrusion. Request federal documentation, support, and potential enforcement action.",
    priority: 4,
  },
  {
    label: "Request Federal Intervention",
    action: "federal",
    description:
      "Escalate under 18 U.S.C. § 1151 and applicable treaty provisions. Engage the U.S. Attorney or Department of Justice for enforcement.",
    priority: 5,
  },
];

/**
 * Derive recommended_action, reasoning, and ordered next-step options.
 *
 * Priority order:
 * 1. If core_state_rules contains a "recommended_action" rule, use it verbatim.
 * 2. Keyword logic on issues, parties, jurisdiction, and legal matches.
 * 3. Default fallback.
 */
export function deriveActions(
  extraction: ExtractedIntake,
  appliedRules: AppliedRule[],
  _legalMatches: LegalSearchResult[],
): ActionResult {
  const issuesText = extraction.issues.map((i) => i.toLowerCase()).join(" ");
  const partiesText = [
    ...extraction.parties.names,
    ...extraction.parties.agencies,
  ]
    .join(" ")
    .toLowerCase();
  const jurisdictionText = extraction.jurisdiction.toLowerCase();

  const hasLien = /lien|assessment|levy|tax|encumbran/.test(issuesText);
  const hasTrustLand = /trust|allot|indian country|tribal land/.test(
    jurisdictionText + " " + issuesText,
  );
  const isStateActor = /\b(state|county|dept|department|commission|board|assessor|treasurer)\b/.test(
    partiesText,
  );
  const isPrivateActor =
    !isStateActor &&
    extraction.parties.names.length > 0 &&
    extraction.parties.agencies.length === 0;
  const hasFederalTreatyIssue = /treaty|sovereignty|federal|intercourse act|worcester/.test(
    issuesText + " " + jurisdictionText,
  );

  // 1. Rules-based override — highest priority
  const ruleBasedAction = appliedRules.find(
    (r) => r.rule_type === "recommended_action",
  );

  let recommended_action: string;
  let reasoning: string;
  let primaryAction: string;

  if (ruleBasedAction) {
    recommended_action = ruleBasedAction.rule_body;
    reasoning = `Based on the applicable state/jurisdiction rule (priority ${ruleBasedAction.priority}): ${ruleBasedAction.rule_body}.`;
    primaryAction = ruleBasedAction.rule_body.toLowerCase().includes("nfr")
      ? "nfr"
      : ruleBasedAction.rule_body.toLowerCase().includes("complaint")
        ? "complaint"
        : ruleBasedAction.rule_body.toLowerCase().includes("response") ||
            ruleBasedAction.rule_body.toLowerCase().includes("respond")
          ? "respond"
          : "nfr";
  } else if (hasLien && hasTrustLand) {
    recommended_action =
      "Issue Notice of Federal Review (NFR) — Non-Intercourse Act violation";
    reasoning =
      "A lien, assessment, or financial encumbrance on trust or allotted land triggers protections under 25 U.S.C. § 177 (Non-Intercourse Act) and Worcester v. Georgia. An NFR formally asserts Tribal jurisdiction and notifies the Bureau of Indian Affairs.";
    primaryAction = "nfr";
  } else if (isStateActor && hasTrustLand) {
    recommended_action =
      "File Sovereignty Response — State action on Tribal lands";
    reasoning =
      "State agency action affecting trust or allotted land violates the federal preemption doctrine established in McClanahan v. Arizona State Tax Commission. A formal sovereignty response documents the violation and preserves legal remedies.";
    primaryAction = "respond";
  } else if (hasFederalTreatyIssue) {
    recommended_action = "Request Federal Intervention — Treaty violation";
    reasoning =
      "Federal treaty rights or sovereignty claims are implicated. Escalation to the BIA and potential U.S. Department of Justice engagement is warranted under 18 U.S.C. § 1151 and applicable treaty provisions.";
    primaryAction = "federal";
  } else if (isPrivateActor && hasTrustLand) {
    recommended_action =
      "File Tribal Court Complaint — Private actor on Tribal lands";
    reasoning =
      "A private party action occurring on trust or allotted land falls within the exclusive jurisdiction of the Tribal Court. A formal complaint initiates proceedings under Tribal law.";
    primaryAction = "complaint";
  } else {
    recommended_action =
      "File Tribal Court Complaint — Tribal jurisdiction asserted";
    reasoning =
      "Based on the extracted parties, issues, and jurisdictional context, initiating a Tribal Court complaint is the appropriate first step to assert and preserve Tribal jurisdiction.";
    primaryAction = "complaint";
  }

  // Order options so the recommended action is first
  const ordered = [...ALL_OPTIONS].sort((a, b) => {
    if (a.action === primaryAction) return -1;
    if (b.action === primaryAction) return 1;
    return a.priority - b.priority;
  });

  return { recommended_action, reasoning, options: ordered };
}
