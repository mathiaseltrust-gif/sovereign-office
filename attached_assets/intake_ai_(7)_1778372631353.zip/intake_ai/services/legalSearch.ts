import { db } from "@workspace/db";
import { legalProvisions } from "@workspace/db";
import { or, ilike, eq } from "drizzle-orm";

export interface LegalSearchResult {
  provision_id: string;
  title: string;
  citation: string | null;
  body: string;
  jurisdiction: string | null;
  state: string | null;
  relevance_score: number;
}

/**
 * Search the legal_provisions corpus for matching provisions.
 *
 * Strategy:
 *  1. Fetch all rows whose title or body contains at least one search term (ilike).
 *  2. Score each row by total term occurrences in title + body.
 *  3. Apply jurisdiction and state boosts (+5 each) when those fields match.
 *  4. Return the top `limit` results sorted by descending relevance_score.
 */
export async function searchLegalProvisions(
  terms: string[],
  jurisdiction?: string,
  state?: string,
  limit = 10,
): Promise<LegalSearchResult[]> {
  if (terms.length === 0) return [];

  const termConditions = terms.flatMap((term) => [
    ilike(legalProvisions.title, `%${term}%`),
    ilike(legalProvisions.body, `%${term}%`),
  ]);

  const rows = await db
    .select()
    .from(legalProvisions)
    .where(or(...termConditions))
    .limit(limit * 3);

  const scored: LegalSearchResult[] = rows.map((row) => {
    const haystack = `${row.title} ${row.body}`.toLowerCase();
    const termScore = terms.reduce((acc, term) => {
      const hits = (haystack.match(new RegExp(term.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) ?? []).length;
      return acc + hits;
    }, 0);

    const jurisdictionBoost =
      jurisdiction && row.jurisdiction?.toLowerCase() === jurisdiction.toLowerCase() ? 5 : 0;
    const stateBoost =
      state && row.state?.toUpperCase() === state.toUpperCase() ? 5 : 0;

    return {
      provision_id: row.provision_id,
      title: row.title,
      citation: row.citation,
      body: row.body,
      jurisdiction: row.jurisdiction,
      state: row.state,
      relevance_score: termScore + jurisdictionBoost + stateBoost,
    };
  });

  return scored
    .sort((a, b) => b.relevance_score - a.relevance_score)
    .slice(0, limit);
}
