# MET Command Registry

Private internal registry for land, entities, incidents, evidence, extraction review, notices, and federal action preparation.

## Core Flow

Evidence Uploads → Extraction Layer → Review Queue → Core Registry → Notice / Complaint / Exhibit Generator

## Quick Start

```bash
python scripts/setup_db.py
python scripts/add_land.py
python scripts/add_entity.py
python scripts/add_incident.py
python scripts/extract_file.py evidence/raw/sample.txt
python scripts/review_extractions.py
python scripts/generate_notice.py
```

## Tables

- lands
- entities
- incidents
- documents
- evidence_files
- extractions
- extraction_findings
- notices
- service_log
