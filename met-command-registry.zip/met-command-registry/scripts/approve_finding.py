import sqlite3, sys
from setup_db import DB_PATH

if len(sys.argv) < 2:
    print("Usage: python scripts/approve_finding.py FINDING_ID")
    sys.exit(1)

finding_id = sys.argv[1]
con = sqlite3.connect(DB_PATH)
con.execute("UPDATE extraction_findings SET accepted = 1 WHERE finding_id = ?", (finding_id,))
con.commit()
con.close()
print(f"Approved finding: {finding_id}")
