import sqlite3, uuid
from pathlib import Path
from setup_db import DB_PATH

BASE = Path(__file__).resolve().parents[1]
template = (BASE / "templates" / "notice_of_federal_review.md").read_text()

incident_id = input("Incident ID: ").strip()
con = sqlite3.connect(DB_PATH)
con.row_factory = sqlite3.Row
row = con.execute("""
SELECT i.*, l.name AS land_name, e.name AS entity_name
FROM incidents i
LEFT JOIN lands l ON i.land_id = l.land_id
LEFT JOIN entities e ON i.entity_id = e.entity_id
WHERE i.incident_id = ?
""", (incident_id,)).fetchone()

if not row:
    print("Incident not found.")
    raise SystemExit

content = template
for key in ["incident_id", "land_name", "entity_name", "federal_trigger", "description"]:
    content = content.replace("{{" + key + "}}", str(row[key] or ""))

out = BASE / "exports" / f"{incident_id}_notice_of_federal_review.md"
out.write_text(content)

notice_id = f"NOT-{uuid.uuid4().hex[:8].upper()}"
con.execute("""
INSERT INTO notices (notice_id, incident_id, title, notice_type, generated_file_path)
VALUES (?, ?, ?, ?, ?)
""", (notice_id, incident_id, "Notice of Federal Review", "MET-NFR-26-001", str(out)))
con.commit()
con.close()
print(f"Generated: {out}")
