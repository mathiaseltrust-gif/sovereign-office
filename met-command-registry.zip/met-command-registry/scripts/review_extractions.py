import sqlite3
from setup_db import DB_PATH

con = sqlite3.connect(DB_PATH)
rows = con.execute("""
SELECT f.finding_id, f.extraction_id, f.field_name, f.field_value, f.confidence, f.accepted
FROM extraction_findings f
ORDER BY f.created_at DESC
""").fetchall()

if not rows:
    print("No extraction findings yet.")
else:
    for r in rows:
        print(f"{r[0]} | {r[2]} | {r[3]} | confidence={r[4]} | accepted={r[5]}")
con.close()
