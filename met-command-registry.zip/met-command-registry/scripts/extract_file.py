import sqlite3, uuid, re, sys
from pathlib import Path
from setup_db import DB_PATH

def detect(text):
    dates = re.findall(r"\b(?:\d{1,2}/\d{1,2}/\d{2,4}|\d{4}-\d{2}-\d{2}|[A-Z][a-z]+ \d{1,2}, \d{4})\b", text)
    amounts = re.findall(r"\$[\d,]+(?:\.\d{2})?", text)
    case_numbers = re.findall(r"\b(?:Case|No\.|Case No\.|Docket)\s*[:#]?\s*[A-Za-z0-9:\-cvCV\.]+\b", text)
    apns = re.findall(r"\b(?:APN|Parcel|ATN)\s*[:#]?\s*[A-Za-z0-9\-\.]+\b", text)
    possible_addresses = re.findall(r"\b\d{2,6}\s+[A-Za-z0-9 .'-]+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Boulevard|Blvd|Lane|Ln|Court|Ct|Way|Place|Pl)\b", text, flags=re.I)
    return dates, amounts, case_numbers, apns, possible_addresses

if len(sys.argv) < 2:
    print("Usage: python scripts/extract_file.py evidence/raw/yourfile.txt")
    sys.exit(1)

file_path = Path(sys.argv[1])
text = file_path.read_text(errors="ignore")
dates, amounts, case_numbers, apns, addresses = detect(text)

con = sqlite3.connect(DB_PATH)
evidence_id = f"EV-{uuid.uuid4().hex[:8].upper()}"
extraction_id = f"EXT-{uuid.uuid4().hex[:8].upper()}"

con.execute("""
INSERT INTO evidence_files (evidence_id, file_path, file_type, notes)
VALUES (?, ?, ?, ?)
""", (evidence_id, str(file_path), file_path.suffix.lower(), "Auto-imported for extraction"))

con.execute("""
INSERT INTO extractions
(extraction_id, evidence_id, extracted_text, detected_dates, detected_amounts, detected_case_numbers, detected_apn, detected_addresses, confidence_score)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
""", (
    extraction_id, evidence_id, text[:20000],
    ", ".join(dates), ", ".join(amounts), ", ".join(case_numbers),
    ", ".join(apns), ", ".join(addresses), 0.65
))

findings = []
for field, values in [
    ("detected_date", dates),
    ("detected_amount", amounts),
    ("detected_case_number", case_numbers),
    ("detected_apn", apns),
    ("detected_address", addresses),
]:
    for v in values:
        findings.append((f"FND-{uuid.uuid4().hex[:8].upper()}", extraction_id, field, v, 0.65))

con.executemany("""
INSERT INTO extraction_findings (finding_id, extraction_id, field_name, field_value, confidence)
VALUES (?, ?, ?, ?, ?)
""", findings)

con.commit()
con.close()
print(f"Evidence saved: {evidence_id}")
print(f"Extraction saved: {extraction_id}")
print(f"Findings saved: {len(findings)}")
