import sqlite3, uuid
from setup_db import DB_PATH

def ask(label):
    return input(f"{label}: ").strip()

con = sqlite3.connect(DB_PATH)
entity_id = ask("Entity ID, example ENT-KERN-RECORDER-001") or f"ENT-{uuid.uuid4().hex[:8].upper()}"
data = {
    "entity_id": entity_id,
    "name": ask("Entity name"),
    "entity_type": ask("Entity type"),
    "address": ask("Address"),
    "email": ask("Email"),
    "phone": ask("Phone"),
    "role_or_issue": ask("Role or issue"),
    "notes": ask("Notes"),
}
con.execute("""
INSERT OR REPLACE INTO entities
(entity_id, name, entity_type, address, email, phone, role_or_issue, notes)
VALUES (:entity_id, :name, :entity_type, :address, :email, :phone, :role_or_issue, :notes)
""", data)
con.commit()
con.close()
print(f"Saved entity: {entity_id}")
