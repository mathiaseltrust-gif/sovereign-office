import sqlite3, uuid
from setup_db import DB_PATH

def ask(label):
    return input(f"{label}: ").strip()

con = sqlite3.connect(DB_PATH)
incident_id = ask("Incident ID, example MET-IR-2026-001") or f"MET-IR-{uuid.uuid4().hex[:8].upper()}"
data = {
    "incident_id": incident_id,
    "land_id": ask("Related land ID"),
    "entity_id": ask("Related entity ID"),
    "incident_date": ask("Incident date YYYY-MM-DD"),
    "issue_type": ask("Issue type"),
    "description": ask("Description"),
    "federal_trigger": ask("Federal trigger"),
    "status": ask("Status") or "open",
    "notes": ask("Notes"),
}
con.execute("""
INSERT INTO incidents
(incident_id, land_id, entity_id, incident_date, issue_type, description, federal_trigger, status, notes)
VALUES (:incident_id, :land_id, :entity_id, :incident_date, :issue_type, :description, :federal_trigger, :status, :notes)
""", data)
con.commit()
con.close()
print(f"Saved incident: {incident_id}")
