import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "met_registry.db"

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)

schema = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS lands (
    land_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    state TEXT,
    county TEXT,
    apn TEXT,
    legal_description TEXT,
    trust_status TEXT,
    case_numbers TEXT,
    protected_status TEXT,
    household_or_beneficiary TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS entities (
    entity_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    entity_type TEXT,
    address TEXT,
    email TEXT,
    phone TEXT,
    role_or_issue TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS incidents (
    incident_id TEXT PRIMARY KEY,
    land_id TEXT,
    entity_id TEXT,
    incident_date TEXT,
    issue_type TEXT,
    description TEXT,
    federal_trigger TEXT,
    status TEXT DEFAULT 'open',
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (land_id) REFERENCES lands(land_id),
    FOREIGN KEY (entity_id) REFERENCES entities(entity_id)
);

CREATE TABLE IF NOT EXISTS documents (
    document_id TEXT PRIMARY KEY,
    incident_id TEXT,
    title TEXT NOT NULL,
    document_type TEXT,
    file_path TEXT,
    date_created TEXT,
    served_on TEXT,
    service_method TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES incidents(incident_id)
);

CREATE TABLE IF NOT EXISTS evidence_files (
    evidence_id TEXT PRIMARY KEY,
    file_path TEXT NOT NULL,
    file_type TEXT,
    uploaded_date TEXT DEFAULT CURRENT_TIMESTAMP,
    related_land_id TEXT,
    related_entity_id TEXT,
    notes TEXT,
    FOREIGN KEY (related_land_id) REFERENCES lands(land_id),
    FOREIGN KEY (related_entity_id) REFERENCES entities(entity_id)
);

CREATE TABLE IF NOT EXISTS extractions (
    extraction_id TEXT PRIMARY KEY,
    evidence_id TEXT NOT NULL,
    extracted_text TEXT,
    detected_names TEXT,
    detected_addresses TEXT,
    detected_dates TEXT,
    detected_apn TEXT,
    detected_case_numbers TEXT,
    detected_amounts TEXT,
    detected_deadlines TEXT,
    confidence_score REAL,
    reviewed INTEGER DEFAULT 0,
    approved_for_registry INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (evidence_id) REFERENCES evidence_files(evidence_id)
);

CREATE TABLE IF NOT EXISTS extraction_findings (
    finding_id TEXT PRIMARY KEY,
    extraction_id TEXT NOT NULL,
    field_name TEXT,
    field_value TEXT,
    confidence REAL,
    accepted INTEGER DEFAULT 0,
    linked_table TEXT,
    linked_record_id TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (extraction_id) REFERENCES extractions(extraction_id)
);

CREATE TABLE IF NOT EXISTS notices (
    notice_id TEXT PRIMARY KEY,
    incident_id TEXT,
    title TEXT,
    notice_type TEXT,
    generated_file_path TEXT,
    status TEXT DEFAULT 'draft',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES incidents(incident_id)
);

CREATE TABLE IF NOT EXISTS service_log (
    service_id TEXT PRIMARY KEY,
    notice_id TEXT,
    entity_id TEXT,
    service_date TEXT,
    service_method TEXT,
    tracking_number TEXT,
    proof_file_path TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (notice_id) REFERENCES notices(notice_id),
    FOREIGN KEY (entity_id) REFERENCES entities(entity_id)
);
"""

if __name__ == "__main__":
    con = connect()
    con.executescript(schema)
    con.commit()
    con.close()
    print(f"Database created at: {DB_PATH}")
