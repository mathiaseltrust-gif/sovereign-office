import sqlite3, uuid
from pathlib import Path
from setup_db import DB_PATH

def ask(label):
    return input(f"{label}: ").strip()

con = sqlite3.connect(DB_PATH)
land_id = ask("Land ID, example MET-TL-BC-001") or f"LAND-{uuid.uuid4().hex[:8].upper()}"
data = {
    "land_id": land_id,
    "name": ask("Land name"),
    "state": ask("State"),
    "county": ask("County"),
    "apn": ask("APN / parcel number"),
    "legal_description": ask("Legal description"),
    "trust_status": ask("Trust/restricted status"),
    "case_numbers": ask("Case numbers"),
    "protected_status": ask("Protected status"),
    "household_or_beneficiary": ask("Household/beneficiary"),
    "notes": ask("Notes"),
}
con.execute("""
INSERT OR REPLACE INTO lands
(land_id, name, state, county, apn, legal_description, trust_status, case_numbers, protected_status, household_or_beneficiary, notes)
VALUES (:land_id, :name, :state, :county, :apn, :legal_description, :trust_status, :case_numbers, :protected_status, :household_or_beneficiary, :notes)
""", data)
con.commit()
con.close()
print(f"Saved land: {land_id}")
