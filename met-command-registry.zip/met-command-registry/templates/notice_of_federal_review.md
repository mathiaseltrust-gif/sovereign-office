# NOTICE OF FEDERAL REVIEW

**Form No.:** MET-NFR-26-001  
**Related Incident:** {{incident_id}}  
**Related Land:** {{land_name}}  
**Related Entity:** {{entity_name}}  

## Notice

This Notice of Federal Review is issued to preserve and identify federal questions, tribal land implications, trust/restricted land concerns, and any encumbrance, interference, recording obstruction, foreclosure activity, taxation activity, lien activity, or adverse property action affecting the protected interests identified herein.

## Federal Triggers

{{federal_trigger}}

## Incident Summary

{{description}}

## Direction

The receiving party is placed on notice to preserve all records, suspend adverse action where federal Indian law protections are implicated, and refrain from creating, enforcing, transferring, recording, or relying upon any encumbrance inconsistent with federal law.

## Reservation

All rights, remedies, objections, and jurisdictional positions are preserved.
