# Federal Declaratory and Injunctive Relief Complaint Outline

## 1. Caption

The Mathias El Tribe, an identifiable group of American Indians, Plaintiff  
v.  
[Defendants]

## 2. Jurisdiction

- 28 U.S.C. § 1331
- 28 U.S.C. § 1362, where applicable
- 28 U.S.C. §§ 2201–2202
- Federal Indian law
- Non-Intercourse Act, 25 U.S.C. § 177
- Supremacy Clause
- Federal common law

## 3. Nature of Action

Declaratory and injunctive relief against interference, encumbrance, foreclosure, taxation, recording obstruction, and adverse enforcement actions affecting federally protected tribal/restricted land interests.

## 4. Federal Questions Presented

1. Whether state/county/private actors may impose or enforce encumbrances against protected tribal or Indian land interests contrary to federal law.
2. Whether adverse title, tax, foreclosure, or recording actions are preempted.
3. Whether injunctive relief is necessary to preserve the status quo.

## 5. Causes of Action

- Count I: Declaratory Relief
- Count II: Federal Preemption / Supremacy Clause
- Count III: Non-Intercourse Act / Unlawful Encumbrance
- Count IV: Ultra Vires State or County Action
- Count V: Injunctive Relief

## 6. Prayer for Relief

- Declare encumbrances void or unenforceable to the extent they conflict with federal law.
- Enjoin foreclosure, lien enforcement, tax sale, recording obstruction, and adverse title acts.
- Preserve all property records and evidence.
- Grant further relief under 28 U.S.C. § 2202.
